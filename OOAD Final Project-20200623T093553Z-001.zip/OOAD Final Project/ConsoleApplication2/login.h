#pragma once
#include<string>
#include<iostream>
using namespace std;
class login
{
private:
	string EmployeeName = "Saad Asif";
	string password = "12345";
	static int count;
public:
	login();
	static int getcount();
	~login();
};

