#include "Supermarket.h"


Supermarket::Supermarket()
{
}


Supermarket::~Supermarket()
{
}
