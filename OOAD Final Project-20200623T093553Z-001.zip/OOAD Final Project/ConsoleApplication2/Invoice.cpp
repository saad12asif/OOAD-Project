#include "Invoice.h"
#include "items.h"
using namespace std;

Invoice::Invoice()
{
	computeBill();
}
void Invoice::computeBill()
{
	cout << "-------------------------------------------------" << endl;
	cout << "                 Billing slip                    " << endl;
	cout << "-------------------------------------------------" << endl;
	cout << "_________________________________________________" << endl << endl;
	bill = 0;
	ifstream fin;
	fin.open("invoice.txt");
	while (!fin.eof())
	{
		fin >> id;
		cout << id << " ";
		fin.ignore();
		getline(fin, name, ',');
		cout << name << " ";

		fin >> price;
		cout << price << " ";
		fin.ignore();
		fin >> quantity;
		cout << quantity << " ";
		cout << endl << endl;

		bill = bill + price;
	}
	cout << "_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_" << endl << endl;
	cout << "              Total bill = " << bill<<endl;
	cout << "_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_:_'_" << endl << endl;
	cout << "_________________________________________________" << endl << endl;
}
void Invoice ::priceDetails()
{
	cout << endl;
}
Invoice::~Invoice()
{
}