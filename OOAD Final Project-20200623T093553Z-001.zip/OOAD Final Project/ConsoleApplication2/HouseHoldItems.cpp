#include "HouseHoldItems.h"
using namespace std;


HouseHoldItems::HouseHoldItems() 
{
	cout << "House Hold items ctr " << endl;
	menu();
}
void HouseHoldItems::menu()
{
	ifstream fin;
	fin.open("HouseHoldi-tems.txt");
	int temp = 0;

	do
	{
		system("cls");

		cout << "________________________" << endl;
		cout << endl;
		cout << "For Box Cutter ---------[1]" << endl;
		cout << "For First Aid Kit ------[2]" << endl;
		cout << "For Bulb -------------- [3]" << endl;
		cout << "For Hair Brush -------- [4]" << endl;
		cout << "To Go Back -------------[5]" << endl;
		cout << "________________________" << endl;
		cout << endl;

		cout << "Enter Option: " << endl;


		cin >> temp;
		if (temp == 1)
		{
			int q;
			cout << "Enter the quantity : " << endl;
			cin >> q;

			ifstream fin;
			fin.open("HouseHolditems.txt", ios::in);
			fin >> id;
			fin.ignore();
			getline(fin, name, ',');


			fin >> price;
			fin.ignore();
			fin >> quantity;
			//display();
			fin.close();

			if (q <= quantity)
			{
				ofstream fout;
				fout.open("invoice.txt", ios::app);
				fout << id << "," << name << "," << price*q << "," << q << endl;
				fout.close();
			}
			else
			{
				cout << "Available Quantity is only " << quantity << endl;
			}
		}
		else if (temp == 2)
		{
			int q;
			cout << "Enter the quantity : " << endl;
			cin >> q;

			ifstream fin;
			fin.open("HouseHolditems.txt", ios::in);
			string temp;
			getline(fin, temp, '\n');
			fin >> id;
			fin.ignore();

			getline(fin, name, ',');
			//fin.ignore();

			fin >> price;
			fin.ignore();
			fin >> quantity;
			//display();
			fin.close();

			if (q <= quantity)
			{
				ofstream fout;
				fout.open("invoice.txt", ios::app);
				fout << id << "," << name << "," << price*q << "," << q << endl;
				fout.close();
			}
			else
			{
				cout << "Available Quantity is only " << quantity << endl;
			}
		}
		else if (temp == 3)
		{
			int q;
			cout << "Enter the quantity : " << endl;
			cin >> q;

			ifstream fin;
			fin.open("HouseHolditems.txt", ios::in);
			string temp1;
			getline(fin, temp1, '\n');
			getline(fin, temp1, '\n');
			fin >> id;
			fin.ignore();
			getline(fin, name, ',');
			fin >> price;
			fin.ignore();
			fin >> quantity;
			//display();
			fin.close();

			if (q <= quantity)
			{
				ofstream fout;
				fout.open("invoice.txt", ios::app);
				fout << id << "," << name << "," << price*q << "," << q<< endl;
				fout.close();
			}
			else
			{
				cout << "Available Quantity is only " << quantity << endl;
			}
		}

		else if (temp == 4)
		{
			int q;
			cout << "Enter the quantity : " << endl;
			cin >> q;

			ifstream fin;
			fin.open("HouseHolditems.txt", ios::in);
			string temp;
			getline(fin, temp, '\n');
			getline(fin, temp, '\n');
			getline(fin, temp, '\n');
			fin >> id;
			fin.ignore();
			getline(fin, name, ',');
			fin >> price;
			fin.ignore();
			fin >> quantity;
			//display();
			fin.close();

			if (q <= quantity)
			{
				ofstream fout;
				fout.open("invoice.txt", ios::app);
				fout << id << "," << name << "," << price*q << "," <<q<< endl;
				fout.close();
			}
			else
			{
				cout << "Available Quantity is only " << quantity << endl;
			}
		}
		
	} while (temp != 5);
}

HouseHoldItems::~HouseHoldItems()
{
	cout << "House Hold items dtr " << endl;
}
void HouseHoldItems::priceDetails()
{
	cout << "Price of Box Cutter is 100 Rupees " << endl;
	cout << "Price of First Aid Kir is 1150 Rupees  " << endl;
	cout << "Price of Bulb is 150 Rupees " << endl;
	cout << "Price of Hair Brush is 250 Rupees " << endl;

}
void HouseHoldItems::display()
{
	cout << "Id:" << id << endl;
	cout << "Name:" << name << endl;
	cout << "Price:" << price << endl;
	cout << "Available Quantity : " << quantity << endl;
}