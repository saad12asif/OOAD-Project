#pragma once
//#include "items.h"
class Supermarket
{
public:
	Supermarket();
	virtual void priceDetails() = 0;
	~Supermarket();
};
