#include<iostream>
#include "login.h"
#include "items.h"
#include "CrockeryItems.h"
#include "Supermarket.h"
#include "FoodItems.h"
#include "HouseHoldItems.h"
#include "Invoice.h"
#include <stdio.h>

using namespace std;
int main()
{
	int choice;                      //For menu

	login obj;                       //Log In Class Object
	if (login::getcount() > 0)
	{
		do{
			system("cls");

			cout << "______________________________" << endl;
			cout << "For Crockery Items----------1" << endl;
			cout << "For HouseHold Items---------2" << endl;
			cout << "For Food Items--------------3" << endl;
			cout << "Print Total bill------------4" << endl;
			cout << "For Exit--------------------5" << endl;
			cout << "______________________________" << endl;

			cout << "Select Item Type " << endl;
			cin >> choice;
			Supermarket *sm;
			if (choice == 1)
			{
				sm = new CrockeryItems();
			}
			if (choice == 2)
			{
				sm = new HouseHoldItems();
			}
			if (choice == 3)
			{
				sm = new FoodItems();
			}
			if (choice == 4)
			{
				sm = new Invoice();
			}
			system("pause");
		} while (choice != 5);
	}
	  else
	{
		cout << "You Have to login First " << endl;
	}
	remove("invoice.txt");
	return 0;
}