#pragma once
#include<string.h>
#include <fstream>
#include "items.h"
#include<iostream>
class FoodItems :public items
{
public:
	FoodItems();
	void priceDetails();
	~FoodItems();
	void display();
	void menu();
};
