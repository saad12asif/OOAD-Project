#include "CrockeryItems.h"
using namespace std;
#include <string>
#include <fstream>


CrockeryItems::CrockeryItems()
{
	menu();
}
void CrockeryItems::priceDetails()
{
	cout << "Price of Coffee Mug is 250 Rupees " << endl;
	cout << "Price of Dinner Plate Set is 350 Rupees  " << endl;
	cout << "Price of Glass Set is 250 Rupees " << endl;
	cout << "Price of Grinder is 980 Rupees " << endl;
}
void CrockeryItems::menu()
{
	//if (fin.is_open()) { /* ok, proceed with output */ cout << "File opened\n"; }
	//else { cout << "File not opened\n"; }
	//system("pause");
	int temp = 0;

	do
	{
		system("cls");

		cout << "________________________" << endl;
		cout << endl;
		cout << "For Coffee Mug ------[1]" << endl;
		cout << "For Dinner Plates ---[2]" << endl;
		cout << "For Glass Set ------ [3]" << endl;
		cout << "For Grinder -------- [4]" << endl;
		cout << "To Go Back ----------[5]" << endl;
		cout << "________________________" << endl;
		cout << endl;

		cout << "Enter Option: " << endl;


		cin >> temp;
		if (temp == 1)
		{
			int q;
			cout << "Enter the quantity : " << endl;
			cin >> q;

			ifstream fin;
			fin.open("Crockeryitems.txt", ios::in);
			fin >> id;
			fin.ignore();
			getline(fin, name, ',');


			fin >> price;
			fin.ignore();
			fin >> quantity;
			//display();
			fin.close();

			if (q <= quantity)
			{
				ofstream fout;
				fout.open("invoice.txt", ios::app);
				fout << id << "," << name << "," << price*q << "," << q << endl;
				fout.close();
			}
			else
			{
				cout << "Available Quantity is only " << quantity << endl;
			}
		}
		else if (temp == 2)
		{
				int q;
				cout << "Enter the quantity : " << endl;
				cin >> q;

				ifstream fin;
				fin.open("Crockeryitems.txt", ios::in);
				string temp;
				getline(fin, temp, '\n');
				fin >> id;
				fin.ignore();

				getline(fin, name, ',');
				//fin.ignore();

				fin >> price;
				fin.ignore();
				fin >> quantity;
				//display();
				fin.close();

				if (q <= quantity)
				{
					ofstream fout;
					fout.open("invoice.txt", ios::app);
					fout << id << "," << name << "," << price*q << "," << q <<  endl;
					fout.close();
				}
				else
				{
					cout << "Available Quantity is only " << quantity << endl;
				}
			}
			else if (temp == 3)
			{
					int q;
					cout << "Enter the quantity : " << endl;
					cin >> q;

					ifstream fin;
					fin.open("Crockeryitems.txt", ios::in);
					string temp1;
					getline(fin, temp1, '\n');
					getline(fin, temp1, '\n');
					fin >> id;
					fin.ignore();
					getline(fin, name, ',');
					fin >> price;
					fin.ignore();
					fin >> quantity;
				//	display();
					fin.close();

					if (q <= quantity)
					{
						ofstream fout;
						fout.open("invoice.txt", ios::app);
						fout << id << "," << name << "," << price*q << "," << q << endl;
						fout.close();
					}
					else
					{
						cout << "Available Quantity is only " << quantity << endl;
					}
				}

				else if (temp == 4)
				{
						int q;
						cout << "Enter the quantity : " << endl;
						cin >> q;

						ifstream fin;
						fin.open("Crockeryitems.txt", ios::in);
						string temp;
						getline(fin, temp, '\n');
						getline(fin, temp, '\n');
						getline(fin, temp, '\n');
						fin >> id;
						fin.ignore();
						getline(fin, name, ',');
						fin >> price;
						fin.ignore();
						fin >> quantity;
						//display();
						fin.close();

						if (q <= quantity)
						{
							ofstream fout;
							fout.open("invoice.txt", ios::app);
							fout << id << "," << name << "," << price*q << "," << q <<  endl;
							fout.close();
						}
						else
						{
							cout << "Available Quantity is only " << quantity << endl;
						}
					}
				
			} while (temp != 5);
		}

void CrockeryItems::display()
{
	cout << "Id:" << id << endl;
	cout << "Name:" << name << endl;
	cout << "Price:" << price << endl;
	cout << "Available Quantity : " << quantity << endl;
}

CrockeryItems::~CrockeryItems()
{
}