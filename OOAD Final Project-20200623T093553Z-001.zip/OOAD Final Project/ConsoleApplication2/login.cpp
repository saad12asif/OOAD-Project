#include "login.h"
int login::count = 0;

login::login()
{
	string EmpName;
	cout << "-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-" << endl;
	cout << "                                Please Login First                                               " << endl;
	cout << "-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-" << endl;
	cout << endl << endl;
	cout << "      Username : ";
	getline(cin, EmpName);
	cout << endl << endl << endl;
	string pass;
	cout << "      Enter password : ";
	getline(cin, pass);
	cout << endl;



	if ((EmpName == EmployeeName) && (pass == password))
	{
		cout << "             <______________________________________>            " << endl;
		cout << "             <-------------------------------------->            " << endl;
		cout << "             Welcome To Super Market Mangement System :)         " << endl;
		cout << "             <-------------------------------------->            " << endl;
		cout << "             <______________________________________>            " << endl;
		count++;
		system("pause");
	}
	else
	{
		cout << " Invalid Username || password " << endl;
	}
}
int login::getcount()
{
	return count;
}

login::~login()
{

}
