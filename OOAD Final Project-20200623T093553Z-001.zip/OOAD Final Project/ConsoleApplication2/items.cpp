#include "items.h"


items::items()
{
	
}

items::~items()
{
	
}