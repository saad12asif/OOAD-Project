#pragma once
#include<string.h>
#include "items.h"
#include<iostream>
class HouseHoldItems :public items
{
public:
	HouseHoldItems();
	void priceDetails();
	~HouseHoldItems();
	void display();
	void menu();
};
