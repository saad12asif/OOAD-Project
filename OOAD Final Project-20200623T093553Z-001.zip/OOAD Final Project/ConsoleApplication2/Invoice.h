#pragma once
#include<fstream>
#include "items.h"
class Invoice:public items
{
protected:
	double bill;
	double discount;
public:
	Invoice();
	~Invoice();
	void display();
	void priceDetails();
	void computeBill();
};
