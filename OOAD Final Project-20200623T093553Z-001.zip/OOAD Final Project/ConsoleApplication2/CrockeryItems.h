#pragma once
#include<string.h>
#include <fstream>
#include "items.h"
#include<iostream>
class CrockeryItems :public items
{
public:
	CrockeryItems();
	void priceDetails();
	~CrockeryItems();
	void display();
	void menu();
};
