#pragma once
#include<string>
#include<fstream>
#include<iostream>
#include "Supermarket.h"
using namespace std;
class items :public Supermarket
{
protected:
	string name;
	double id;
	double price;
	int quantity;
public:
	items();
	virtual void priceDetails() = 0;
	~items();
};
